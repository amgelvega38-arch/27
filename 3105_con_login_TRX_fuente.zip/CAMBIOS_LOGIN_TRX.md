# Cambios de acceso 3105

- Pantalla de acceso rediseñada con estética oscura, tarjeta central, icono de llave, campo mostrar/ocultar y botón morado degradado.
- Key local de prueba: `TRX` (no distingue mayúsculas/minúsculas).
- `TRX` crea una sesión temporal de administrador en memoria; no se guarda en Keychain ni se envía al servidor.
- Las demás keys siguen usando la validación HTTPS configurada en el proyecto.
- Este paquete contiene el proyecto fuente Xcode; no es un IPA compilado ni firmado.
